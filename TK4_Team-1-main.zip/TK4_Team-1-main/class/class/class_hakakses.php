<?php

class Hakakses {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db->getConnection();
    }

    // Menambahkan data hakakses
    public function tambahakases($idakses, $namaakses, $keterangan) {
        $query = "INSERT INTO hakakses (idakses, namaakses, keterangan) VALUES (:idakses, :namaakses, :keterangan)";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idakses', $idakses);
        $stmt->bindParam(':namaakses', $namaakses);
        $stmt->bindParam(':keterangan', $keterangan);
		$stmt->bindParam(':keterangan', $keterangan);

        return $stmt->execute();
    }

    // Mengambil semua data hakakses
    public function ambilSemuaDataHakakses() {
        $query = "SELECT * FROM hakakses";
        $stmt = $this->koneksi->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mengambil data hakakses berdasarkan ID
    public function ambilDataAksesByID($idakses) {
        $query = "SELECT * FROM hakalses WHERE idakses = :idakses";
        $stmt = $this->koneksi->prepare($query);
        $stmt->bindParam(':idakses', $idakses);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Mengupdate data hakakses
    public function updateHakakses($idakses, $namaakses, $keterangan) {
        $query = "UPDATE hakakses SET namaakses = :namaakses, keterangan = :keterangan WHERE idakses = :idakses";
        $stmt = $this->koneksi->prepare($query);

		$stmt->bindParam(':idakses', $idakses);
        $stmt->bindParam(':namaakses', $namaakses);
        $stmt->bindParam(':keterangan', $keterangan);
		

        return $stmt->execute();
    }

    // Menghapus data hakakses
    public function hapusHakakses($idakses) {
        $query = "DELETE FROM hakakses WHERE idakses = :idakses";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idakses', $idakses);

        return $stmt->execute();
    }
}
?>
