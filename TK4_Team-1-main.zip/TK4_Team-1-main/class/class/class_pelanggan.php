<?php

class Pelanggan {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db->getConnection();
    }

    // Menambahkan data pelanggan
    public function tambahPelanggan($idpelanggn, $namapelanggan, $alamatpelanggan, $notelppelanggan, $emailpelanggan, $idpenjual ) {
        $query = "INSERT INTO pelanggan (idpelanggn, namapelanggan, alamatpelanggan, notelppelanggan, emailpelanggan, idpenjual) VALUES (:idpelanggn, :namapelanggan, :alamatpelanggan, :notelppelanggan, :emailpelanggan, :idpenjual)";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpelanggn', $idpelanggn);
        $stmt->bindParam(':namapelanggan', $namapelanggan);
        $stmt->bindParam(':alamatpelanggan', $alamatpelanggan);
        $stmt->bindParam(':notelppelanggan', $notelppelanggan);
		$stmt->bindParam(':emailpelanggan', $emailpelanggan);
        $stmt->bindParam(':idpenjual', $idpenjual);


        return $stmt->execute();
    }

    // Mengambil semua data pelanggan
    public function ambilSemuaDataPelanggan() {
        $query = "SELECT * FROM pelanggan";
        $stmt = $this->koneksi->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mengambil data pelanggan berdasarkan ID
    public function ambilDataPelangganByID($idpelanggn) {
        $query = "SELECT * FROM pelanggan WHERE idpelanggan = :idpelanggan";
        $stmt = $this->koneksi->prepare($query);
        $stmt->bindParam(':idpelanggan', $idpelanggan);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Mengupdate data pelanggan
    public function updatePelanggan($idpelanggn, $namapelanggan, $alamatpelanggan, $notelppelanggan, $emailpelanggan, $idpenjual) {
        $query = "UPDATE pelanggan SET namapelanggan = :namapelanggan, alamatpelanggan = :alamatpelanggan, notelppelanggan = :notelppelanggan, emailpelanggan = :emailpelanggan, idpenjual = :idpenjual WHERE idpelanggan = :idpelanggan";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpelanggn', $idpelanggn);
        $stmt->bindParam(':namapelanggan', $namapelanggan);
        $stmt->bindParam(':alamatpelanggan', $alamatpelanggan);
        $stmt->bindParam(':notelppelanggan', $notelppelanggan);
		$stmt->bindParam(':emailpelanggan', $emailpelanggan);
        $stmt->bindParam(':idpenjual', $idpenjual);

        return $stmt->execute();
    }

    // Menghapus data pelanggan
    public function hapusPelanggan($idpelanggn) {
        $query = "DELETE FROM pelanggan WHERE idpelanggn = :idpelanggn";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpelanggn', $idpelanggn);

        return $stmt->execute();
    }
}
?>
