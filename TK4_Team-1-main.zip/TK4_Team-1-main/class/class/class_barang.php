<?php

class Barang {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db->getConnection();
    }

    // Menambahkan data barang
    public function tambahBarang($idbarang, $namabarang, $keterangan, $satuan, $idpengguna) {
        $query = "INSERT INTO barang (idbarang, namabarang, keterangan, satuan, idpengguna) VALUES (:idbarang, :namabarang, :keterangan, :satuan, :idpengguna)";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idbarang', $idbarang);
        $stmt->bindParam(':namabarang', $namabarang);
        $stmt->bindParam(':keterangan', $keterangan);
		$stmt->bindParam(':satuan', $satuan);
		$stmt->bindParam(':idpengguna', $idpengguna);

        return $stmt->execute();
    }

    // Mengambil semua data barang
    public function ambilSemuaDataBarang() {
        $query = "SELECT * FROM barang";
        $stmt = $this->koneksi->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mengambil data barang berdasarkan ID
    public function ambilDataBarangByID($idbarang) {
        $query = "SELECT * FROM barang WHERE idbarang = :idbarang";
        $stmt = $this->koneksi->prepare($query);
        $stmt->bindParam(':idbarang', $idbarang);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Mengupdate data barang
    public function updateBarang($idbarang, $namabarang, $keterangan, $satuan, $idpengguna) {
        $query = "UPDATE barang SET namabarang = :namabarang, keterangan = :keterangan, satuan = :satuan, idpengguna = :idpengguan WHERE idbarang = :idbarang";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idbarang', $idbarang);
        $stmt->bindParam(':namabarang', $namabarang);
        $stmt->bindParam(':keterangan', $keterangan);
		$stmt->bindParam(':satuan', $satuan);
		$stmt->bindParam(':idpengguna', $idpengguna);

        return $stmt->execute();
    }

    // Menghapus data barang
    public function hapusBarang($idbarang) {
        $query = "DELETE FROM barang WHERE idbarang = :idbarang";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idbarang', $idbarang);

        return $stmt->execute();
    }
}
?>
