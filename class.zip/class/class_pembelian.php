<?php

class Pembelian {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db->getConnection();
    }

    // Menambahkan data pembelian
    public function tambahPembelian($idpembelian, $jumlahpembelian, $hargabeli, $idbarang) {
        $query = "INSERT INTO pembelian (idpembelian, jumlahpembelian, hargabeli, idbarang) VALUES (:idpembelian, :jumlahpembelian, :hargabeli, :idbarang)";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpembelian', $idpembelian);
        $stmt->bindParam(':jumlahpembelian', $jumlahpembelian);
        $stmt->bindParam(':hargabeli', $hargabeli);
		$stmt->bindParam(':idbarang', $idbarang);

        return $stmt->execute();
    }

    // Mengambil semua data pembelian
    public function ambilSemuaDataPembelian() {
        $query = "SELECT * FROM pembelian";
        $stmt = $this->koneksi->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mengambil data pembelian berdasarkan ID
    public function ambilDataPembelianByID($idpembelian) {
        $query = "SELECT * FROM pembelian WHERE idpembelian = :idpembelian";
        $stmt = $this->koneksi->prepare($query);
        $stmt->bindParam(':idpembelian', $idpembelian);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Mengupdate data pembelian
    public function updatePembelian($idpembelian, $jumlahpembelian, $hargabeli, $idbarang) {
        $query = "UPDATE pembelian SET jumlahpembelian = :jumlahpembelian, hargabeli = :hargabeli, idbarang = :idbarang WHERE idpembelian = :idpembelian";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpembelian', $idpembelian);
        $stmt->bindParam(':jumlahpembelian', $jumlahpembelian);
        $stmt->bindParam(':hargabeli', $hargabeli);
		$stmt->bindParam(':idbarang', $idbarang);

        return $stmt->execute();
    }

    // Menghapus data pembelian
    public function hapusPembelian($idpembelian) {
        $query = "DELETE FROM pembelian WHERE idpembelian = :idpembelian";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpembelian', $idpembelian);

        return $stmt->execute();
    }
}
?>
