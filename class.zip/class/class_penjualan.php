<?php

class Penjualan {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db->getConnection();
    }

    // Menambahkan data Penjualan
    public function tambahPenjualan($idpenjualan, $jumlahpenjualan, $hargajual, $idbarang) {
        $query = "INSERT INTO penjualan (idpenjualan, jumlahpenjualan, hargajual, idbarang) VALUES (:idpenjualan, :jumlahpenjualan, :hargajual, :idbarang)";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpenjualan', $idpenjualan);
        $stmt->bindParam(':jumlahpenjualan', $jumlahpenjualan);
        $stmt->bindParam(':hargajual', $hargajual);
		$stmt->bindParam(':idbarang', $idbarang);

        return $stmt->execute();
    }

    // Mengambil semua data Penjualan
    public function ambilSemuaDataPenjualan() {
        $query = "SELECT * FROM penjualan";
        $stmt = $this->koneksi->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mengambil data Penjualan berdasarkan ID
    public function ambilDataPenjualanByID($idpenjualan) {
        $query = "SELECT * FROM penjualan WHERE idpenjualan = :idpenjualan";
        $stmt = $this->koneksi->prepare($query);
        $stmt->bindParam(':idpenjualan', $idpenjualan);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Mengupdate data Penjualan
    public function updatePenjualan($idpenjualan, $jumlahpenjualan, $hargajual, $idbarang) {
        $query = "UPDATE penjualan SET jumlahpenjualan = :jumlahpenjualan, hargajual = :hargajual, idbarang = :idbarang WHERE idpenjualan = :idpenjualan";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpenjualan', $idpenjualan);
        $stmt->bindParam(':jumlahpenjualan', $jumlahpenjualan);
        $stmt->bindParam(':hargajual', $hargajual);
		$stmt->bindParam(':idbarang', $idbarang);

        return $stmt->execute();
    }

    // Menghapus data Penjualan
    public function hapusPenjualan($idpenjualan) {
        $query = "DELETE FROM penjualan WHERE idpenjualan = :idpenjualan";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpenjualan', $idpenjualan);

        return $stmt->execute();
    }
}
?>
