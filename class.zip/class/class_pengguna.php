<?php

class Pengguna {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db->getConnection();
    }

    // Menambahkan data pengguna
    public function tambahPengguna($idpengguna, $namapengguna, $password, $namadepan, $namabelakang, $nohp, $alamat, $idakses) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $query = "INSERT INTO pengguna (idpengguna, namapengguna, password, namadepan, namabelakang, nohp, alamat, idakses) VALUES (:idpengguna, :namapengguna, :password, :namadepan, :namabelakang, :nohp, :alamat, :idakses)";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpengguna', $idpengguna);
		$stmt->bindParam(':namapengguna', $namapengguna);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':namadepan', $namadepan);
        $stmt->bindParam(':namabelakang', $namabelakang);
		$stmt->bindParam(':nohp', $nohp);
        $stmt->bindParam(':alamat', $alamat);
        $stmt->bindParam(':idakses', $idakses);

        return $stmt->execute();
    }

    // Mengambil semua data pengguna
    public function ambilSemuaDataPengguna() {
        $query = "SELECT * FROM pengguna";
        $stmt = $this->koneksi->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mengambil data pengguna berdasarkan ID
    public function ambilDataPenggunaByID($idpengguna) {
        $query = "SELECT * FROM pengguna WHERE idpengguna = :idpengguna";
        $stmt = $this->koneksi->prepare($query);
        $stmt->bindParam(':idpengguna', $idpengguna);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Mengupdate data pengguna
    public function updatePengguna($idpengguna, $namapengguna, $password, $namadepan, $namabelakang, $nohp, $alamat, $idakses) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

        $query = "UPDATE pengguna SET namapengguna = :namapengguna, password = :password, namadepan = :namadepan, namabelakang = :namabelakang, nohp = :nohp, alamat = :alamat, idakses = :idakses  WHERE idpengguna = :idpengguna";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpengguna', $idpengguna);
		$stmt->bindParam(':namapengguna', $namapengguna);
        $stmt->bindParam(':password', $hashedPassword);
        $stmt->bindParam(':namadepan', $namadepan);
        $stmt->bindParam(':namabelakang', $namabelakang);
		$stmt->bindParam(':nohp', $nohp);
        $stmt->bindParam(':alamat', $alamat);
        $stmt->bindParam(':idakses', $idakses);

        return $stmt->execute();
    }

    // Menghapus data pengguna
    public function hapusPengguna($idpengguna) {
        $query = "DELETE FROM pengguna WHERE idpengguna = :idpengguna";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idpengguna', $idpengguna);

        return $stmt->execute();
    }
}
?>
