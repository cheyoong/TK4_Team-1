<?php

class Supplier {
    private $koneksi;

    public function __construct($db) {
        $this->koneksi = $db->getConnection();
    }

    // Menambahkan data supplier
    public function tambahSupplier($idsupplier, $namasupplier, $alamatsupplier, $notelpsupplier, $emailsupplier, $idbarang) {
        

        $query = "INSERT INTO supplier (idsupplier, namasupplier, alamatsupplier, notelpsupplier, emailsupplier, idbarang) VALUES (:idsupplier, :namasupplier, :alamatsupplier, :notelpsupplier, :emailsupplier, :idbarang)";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idsupplier', $idsupplier);
		$stmt->bindParam(':namasupplier', $namasupplier);
        $stmt->bindParam(':alamatsupplier', $alamatsupplier);
        $stmt->bindParam(':notelpsupplier', $notelpsupplier);
        $stmt->bindParam(':emailsupplier', $emailsupplier);
		$stmt->bindParam(':idbarang', $idbarang);
  

        return $stmt->execute();
    }

    // Mengambil semua data supplier
    public function ambilSemuaDataSupplier() {
        $query = "SELECT * FROM supplier";
        $stmt = $this->koneksi->prepare($query);
        $stmt->execute();

        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }

    // Mengambil data supplier berdasarkan ID
    public function ambilDataSupplierByID($idsupplier) {
        $query = "SELECT * FROM supplier WHERE idsupplier = :idsupplier";
        $stmt = $this->koneksi->prepare($query);
        $stmt->bindParam(':idsupplier', $idsupplier);
        $stmt->execute();

        return $stmt->fetch(PDO::FETCH_ASSOC);
    }

    // Mengupdate data supplier
    public function updateSupplier($idsupplier, $namasupplier, $alamatsupplier, $notelpsupplier, $emailsupplier, $idbarang) {
      

        $query = "UPDATE supplier SET namasupplier = :namasupplier, alamatsupplier = :alamatsupplier, notelpsupplier = :notelpsupplier, emailsupplier = :emailsupplier, idbarang = :idbarang  WHERE idsupplier = :idsupplier";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idsupplier', $idsupplier);
		$stmt->bindParam(':namasupplier', $namasupplier);
        $stmt->bindParam(':alamatsupplier', $alamatsupplier);
        $stmt->bindParam(':notelpsupplier', $notelpsupplier);
        $stmt->bindParam(':emailsupplier', $emailsupplier);
		$stmt->bindParam(':idbarang', $idbarang);

        return $stmt->execute();
    }

    // Menghapus data supplier
    public function hapusSupplier($idsupplier) {
        $query = "DELETE FROM supplier WHERE idsupplier = :idsupplier";
        $stmt = $this->koneksi->prepare($query);

        $stmt->bindParam(':idsupplier', $idsupplier);

        return $stmt->execute();
    }
}
?>
